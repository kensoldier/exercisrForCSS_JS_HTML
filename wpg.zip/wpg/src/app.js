import css from './ddd.css';
import scss from './app.scss';
import React from 'react';
import ReactDOM from 'react-dom';
import Root from './Root';


ReactDOM.render(
    <Root></Root>,
    document.getElementById('root')
  );